public class name {
    public static void main(String[] args) {
        printFullName();
    }

    static void printFullName() {
        String fullName = "Gaurav Raj"; 
        int length = fullName.length();

        for (int i = 0; i < length; i++) {
            for (int j = 0; j <= i; j++) {
                System.out.print(fullName.charAt(j));
            }
            System.out.println();
        }
    }
}

