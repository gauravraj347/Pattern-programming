public class pwSkills {
    public static void main(String[] args) {
        pwSkills();
    }

    static void pwSkills() {
        String pw = "PW SKILLS"; 
        int length = pw.length();

        for (int i = 0; i < length; i++) {
            for (int j = 0; j <= i; j++) {
                System.out.print(pw.charAt(j));
            }
            System.out.println();
        }
    }
}