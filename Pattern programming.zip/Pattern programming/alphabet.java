
public class alphabet{
    public static void main(String[] args){
        char startchar='A';
        for(int i=1;i<27;i++){
            System.err.print(startchar+" ");
            startchar++;
        }
    }
}
